from django.shortcuts import render
from houses.models import House

# Create your views here.

def houses(request):
    sql = """SELECT 
            houses.*,
            users.name as ownerName,
            users.phone,
            users.email
            FROM houses 
            JOIN users 
            ON users.id=houses.ownerId
            WHERE name LIKE ? 
            OR price LIKE ? O
            R location LIKE ? """
    allHouses = House.objects.all()
    return render(request,"search_houses.html",{"houses":allHouses})
