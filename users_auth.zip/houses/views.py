from django.shortcuts import render,redirect

from houses.models import House
from django.conf import settings

# Create your views here.
def index(request):
    houses = House.objects.all()
    print(settings.MEDIA_URL)
    
    return render(request,"houses.html",{"houses":houses})

def view(request,id):
    house = House.objects.filter(id=id).first()
    return render(request,"description.html",{"house":house})

def create(request):
    return render(request,"create.html")

def store(request):
    name = request.POST["name"]
    House.objects.create(name="House 1")
    return redirect("/admin/houses")

def edit(request,id):
    house = House.objects.filter(id=id).first()

    return render(request,"edit.html",{"house":house})

def update(request,id):
    house = House.objects.filter(id=id).first()
    return redirect("/houses")

def delete(request,id):
    house = House.objects.update(isDeleted=True)
    return redirect("/houses")